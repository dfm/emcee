.. :changelog:

1.1.0 (2012-07-28)
++++++++++++++++++

- Allow the ``lnprobfn`` to return arbitrary "blobs" of data as well as the
  log-probability.
- Python 3 compatible (thanks Alex Conley)!
- Various speed ups and clean ups in the core code base.
- New documentation with better examples and more discussion.


1.0.1 (2012-03-31)
++++++++++++++++++

- Fixed transpose bug in the usage of ``acor`` in ``EnsembleSampler``.


1.0.0 (2012-02-15)
++++++++++++++++++

- Initial release.
