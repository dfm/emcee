Direct contributions to the code base:

- `Dan Foreman-Mackey (NYU) <https://github.com/dfm>`_
- `Dustin Lang (Princeton/CMU) <https://github.com/dstndstn>`_
- `David W. Hogg (NYU) <https://github.com/davidwhogg>`_
- `Alex Conley (U Colorado, Boulder) <https://github.com/aconley314>`_
- `Jeremy Sanders (Cambridge) <https://github.com/jeremysanders>`_
- `Phil Marshall (Oxford) <https://github.com/drphilmarshall>`_

Comments, corrections & suggestions:

- Jonathan Goodman (NYU)
- Jo Bovy (IAS)
- Eric Agol (UWash)
- John Gizis (Delaware)
